<?php
$name = $_post['name'];
$visitor_email = $_post['email'];
$subject = $_post['subject'];
$message = $_post['Message'];


$email_from = 'parioutlook123@gamil.com';

$email_subject = 'New form submission';

$email_body = "User Name: $name.\n".
                "User email: $visitor_email.\n".
                "User subject: $subject.\n".
                "User Message: $Message.\n";

$to = 'parioutlook123@gamil.com';
$headers = "From: $email_from  \r\n";
$headers .="Reply-to:$visitor_email \r\n";
mail($to,$email_subject,$email_body,$headers);
header("location: contact.html");
?>